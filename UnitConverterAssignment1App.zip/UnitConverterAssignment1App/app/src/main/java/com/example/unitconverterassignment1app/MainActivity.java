    package com.example.unitconverterassignment1app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

    public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assigning spinnerUnits to a variable
        Spinner spinnerUnits = (Spinner) findViewById(R.id.spinnerUnits);
        //pulling array to fill the spinner list through an adapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinnerUnitsArray, android.R.layout.simple_spinner_item);
        //Setting dropdown
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //setting array items to spinner
        spinnerUnits.setAdapter(adapter);
        // selection of items in array
        spinnerUnits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                /// Text Box Creations
                // Boxes that show labels
                TextView textShow1 = (TextView) findViewById(R.id.textShow1);
                TextView textShow2 = (TextView) findViewById(R.id.textShow2);
                TextView textShow3 = (TextView) findViewById(R.id.textShow3);

                // Boxes that show output
                TextView textOutput1 = (TextView) findViewById(R.id.textOutput1);
                TextView textOutput2 = (TextView) findViewById(R.id.textOutput2);
                TextView textOutput3 = (TextView) findViewById(R.id.textOutput3);

                // Buttons that will only show when spinner is active on that type of input
                Button measurementButton = (Button) findViewById(R.id.measurementButton);
                Button temperatureButton = (Button) findViewById(R.id.temperatureButton);
                Button weightButton = (Button) findViewById(R.id.weightButton);

                // Switch to declare visibility for relavent items and to determine labels for the following output numbers
                switch (position) {
                    case 0:
                        //Centimeter, Foot and Inch need visibility
                        textShow1.setVisibility(View.VISIBLE);
                        textShow1.setText("Centimeter");
                        textShow2.setVisibility(View.VISIBLE);
                        textShow2.setText("Foot");
                        textShow3.setVisibility(View.VISIBLE);
                        textShow3.setText("Inch");

                        //All outputs need to be visible
                        textOutput1.setVisibility(View.VISIBLE);
                        textOutput2.setVisibility(View.VISIBLE);
                        textOutput3.setVisibility(View.VISIBLE);

                        //Setting uneeded buttons to invisible to not trigger
                        measurementButton.setVisibility(View.VISIBLE);
                        temperatureButton.setVisibility(View.INVISIBLE);
                        weightButton.setVisibility(View.INVISIBLE);
                        break;
                    case 1:
                        //Only 2 text boxes need be visible for Fahrenheit and Kelvin
                        textShow1.setVisibility(View.VISIBLE);
                        textShow1.setText("Farenheit");
                        textShow2.setVisibility(View.VISIBLE);
                        textShow2.setText("Kelvin");
                        textShow3.setVisibility(View.INVISIBLE);

                        //All outputs need to be visible
                        textOutput1.setVisibility(View.VISIBLE);
                        textOutput2.setVisibility(View.VISIBLE);
                        textOutput3.setVisibility(View.INVISIBLE);

                        //Setting uneeded buttons to invisible to not trigger
                        measurementButton.setVisibility(View.INVISIBLE);
                        temperatureButton.setVisibility(View.VISIBLE);
                        weightButton.setVisibility(View.INVISIBLE);
                        break;
                    case 2:
                        //Gram, Ounce and Pound need visibility
                        textShow1.setVisibility(View.VISIBLE);
                        textShow1.setText("Grams");
                        textShow2.setVisibility(View.VISIBLE);
                        textShow2.setText("Ounces");
                        textShow3.setVisibility(View.VISIBLE);
                        textShow3.setText("Pounds");

                        //All outputs need to be visible
                        textOutput1.setVisibility(View.VISIBLE);
                        textOutput2.setVisibility(View.VISIBLE);
                        textOutput3.setVisibility(View.VISIBLE);

                        //Setting uneeded buttons to invisible to not trigger
                        measurementButton.setVisibility(View.INVISIBLE);
                        temperatureButton.setVisibility(View.INVISIBLE);
                        weightButton.setVisibility(View.VISIBLE);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // setting variables via findViewByid
        Button measurementButton = (Button) findViewById(R.id.measurementButton);
        Button temperatureButton = (Button) findViewById(R.id.temperatureButton);
        Button weightButton = (Button) findViewById(R.id.weightButton);

        //Output plain text creation
        final TextView textOutput1 = (TextView) findViewById(R.id.textOutput1);
        final TextView textOutput2 = (TextView) findViewById(R.id.textOutput2);
        final TextView textOutput3 = (TextView) findViewById(R.id.textOutput3);

        //Edit Number creation
        final EditText editTextNumberDecimal = (EditText) findViewById(R.id.editTextNumberDecimal);

        // listener for button click
        measurementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double input = Double.parseDouble(editTextNumberDecimal.getText().toString());      //Parsing input into a double via getText and toString
                textOutput1.setText(String.format("%.2f", input * 100));   //CM
                textOutput2.setText(String.format("%.2f", input * 3.281)); //FT
                textOutput3.setText(String.format("%.2f", input * 39.37)); //INCH
            }
        });

        temperatureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double input = Double.parseDouble(editTextNumberDecimal.getText().toString());
                textOutput1.setText(String.format("%.2f", (input * 1.8) + 100));  //FARENHEIT
                textOutput2.setText(String.format("%.2f", input * 283.15));     //KELVIN
            }
        });

        weightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double input = Double.parseDouble(editTextNumberDecimal.getText().toString());
                textOutput1.setText(String.format("%.2f", input * 1000));      //GRAM
                textOutput2.setText(String.format("%.2f", input * 35.274));    //OZ
                textOutput3.setText(String.format("%.2f", input * 2.205));     //POUND
            }
        });

    }
}